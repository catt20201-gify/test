# Weather API Project

مشروع بسيط يجيب بيانات الطقس من OpenWeather API باستخدام Python.

## الملفات

- `main.py` → الكود الرئيسي ويربط البرنامج بالـ API.
- `.env` → يحتوي API Key الحقيقي، ولا يتم رفعه إلى GitHub.
- `.env.example` → نموذج فقط بدون المفتاح الحقيقي.
- `.gitignore` → يمنع Git من رفع `.env`.
- `requirements.txt` → المكتبات المطلوبة.

## التشغيل

1. ثبتي المكتبات:

```bash
pip install -r requirements.txt
```

2. انسخي `.env.example` وسمّي النسخة `.env`.

3. داخل `.env` اكتبي مفتاحك:

```env
API_KEY=ضع_المفتاح_هنا
```

4. شغلي:

```bash
python main.py
```

## الأمان

المفتاح الحقيقي موجود في `.env` فقط، و`.gitignore` يمنع رفعه إلى GitHub.
